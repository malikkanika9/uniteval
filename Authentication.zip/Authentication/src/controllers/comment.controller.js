const express = require("express")
const User = require("../models/user.models");
const User = require("../models/publication.models");
const User = require("../models/book.models");
const User = require("../models/comment.models");
const User = require("../models/Login.models");


const router = express.Router();


router.post("",  async (req, res) => {
    try {
      
      const comment = await Comment.create({
        body: req.body.content,
      });
      return res.status(200).send(comment);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });


module.exports = router;