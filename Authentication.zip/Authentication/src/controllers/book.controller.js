

const express = require("express")
const User = require("../models/user.models");
const User = require("../models/publication.models");
const User = require("../models/book.models");
const User = require("../models/comment.models");
const User = require("../models/Login.models");
const upload = require("../middlewares/uploads")

const router = express.Router();

router.post("", upload.single("coverImage"), async (req, res) => {
    try {
      
      const book = await Book.create({
          likes:req.body.likes,
        content: req.body.content,
        coverImage: req.file.path,
      });
      return res.status(200).send(book);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });
  
  
      
  async (req, res) => {
    try {
      console.log(body("coverImage"));
      const errors = validationResult(req);
      console.log({ errors });
      if (!errors.isEmpty()) {
        return res.status(400).send({ errors: errors.array() });
      }

      const book = await Book.create(req.body);

      return res.status(201).send(book);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  }



module.exports = router;