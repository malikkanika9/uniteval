

const express = require("express")
const User = require("../models/user.models");
const User = require("../models/publication.models");
const User = require("../models/book.models");
const User = require("../models/comment.models");
const User = require("../models/Login.models");
const upload = require("../middlewares/uploads")

const router = express.Router();

router.post( "/",
  
  body("firstName")
    .trim()
    .not()
    .isEmpty()
    .bail()
    .withMessage("First Name cannot be empty")
    .isLength({ min:3, max:30 })
    .withMessage("First Name must be at least 3 characters"),
    body("lastName").custom((value) => {
      if (value && value.length < 3) {
        throw new Error("Last Name if provided must be at least 3 characters");
      }
      return true;
    }),
    body("lastName")
    .trim()
    .not()
    .isEmpty()
    .bail()
    .withMessage("First Name cannot be empty")
    .isLength({ min: 4 })
    .withMessage("First Name must be at least 3 characters"),
    body("lastName").custom((value) => {
      if (value && value.length < 3) {
        throw new Error("Last Name if provided must be at least 3 characters");
      }
      return true;
    }),
  body("email")
    .isEmail()
    .custom(async (value) => {
      const user = await User.findOne({ email: value });

      if (user) {
        throw new Error("Email is already taken");
      }
      return true;
    }),
   
  body("age")
    .not()
    .isEmpty()
    .withMessage("Age cannot be empty")
    .isNumeric()
    .withMessage("Age must be a number between 1 and 150")
    .custom((val) => {
      if (val < 1 || val > 150) {
        throw new Error("Incorrect age provided");
      }
      return true;
    }),
);

router.post("", upload.single("profilePic"), async (req, res) => {
    try {
      
      const user = await User.create({
        profilePic: req.file.path,
      });
      return res.status(200).send(user);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });
  router.post("/multiple", upload.any("profilePic",5), async (req, res) => {
    try {
      const filePaths = req.files.map((file) => {
        return file.path;
      });
  
      const user = await User.create({
        firstName: req.body.firstName,
        gallery: filePaths,
      });
  
      return res.status(200).send(user);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });
  
      
  async (req, res) => {
    try {
      console.log(body("firstName"));
      const errors = validationResult(req);
      console.log({ errors });
      if (!errors.isEmpty()) {
        return res.status(400).send({ errors: errors.array() });
      }

      const user = await User.create(req.body);

      return res.status(201).send(user);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  }



module.exports = router;