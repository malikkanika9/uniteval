
const mongoose = require("mongoose")
const bookSchema = new mongoose.Schema({
likes:{type: Number, required:true,default:0},
bookname:{type: Number, required:true},
 content:{type: String, required:true},
  coverImage: { type: String, required: false },
  author:{ type: String, required: false },
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "user",
    required: true,
  },
},{
    timestamps : true,
    versionKey : false,
})


const Book = mongoose.model("books", bookSchema)

module.exports = Book;


