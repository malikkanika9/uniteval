
const mongoose = require("mongoose")
const userSchema = new mongoose.Schema({
    firstName:{type: String, required:true},
    firstName:{type: String, required:false},
    age:{type: String, required:false},
    email : {type : String, required : true, unique:true},
    profilePic: [{ type: String, required: false }],
},{
    timestamps : true,
    versionKey : false,
})



const User = mongoose.model("user", userSchema)

module.exports = User;


